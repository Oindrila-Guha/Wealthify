import React, { useState } from 'react';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Plus, Trash2 } from 'lucide-react';
import type { CustomTable } from '../types';

interface NewTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateTable: (table: Omit<CustomTable, 'id'>) => void;
  currentTab: 'income' | 'expenses' | 'assets' | 'liabilities';
}

export const NewTableModal: React.FC<NewTableModalProps> = ({
  isOpen,
  onClose,
  onCreateTable,
  currentTab
}) => {
  const [tableName, setTableName] = useState('');
  const [columns, setColumns] = useState([
    { name: 'Name', type: 'text' as const },
    { name: 'Amount', type: 'number' as const }
  ]);

  const addColumn = () => {
    setColumns([...columns, { name: '', type: 'text' }]);
  };

  const removeColumn = (index: number) => {
    if (columns.length > 1) {
      setColumns(columns.filter((_, i) => i !== index));
    }
  };

  const updateColumn = (index: number, field: 'name' | 'type', value: string) => {
    const newColumns = [...columns];
    newColumns[index] = { ...newColumns[index], [field]: value };
    setColumns(newColumns);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!tableName.trim()) {
      alert('Please enter a table name');
      return;
    }

    if (columns.some(col => !col.name.trim())) {
      alert('Please fill in all column names');
      return;
    }

    onCreateTable({
      name: tableName,
      type: currentTab,
      columns,
      rows: []
    });

    // Reset form
    setTableName('');
    setColumns([
      { name: 'Name', type: 'text' },
      { name: 'Amount', type: 'number' }
    ]);
    onClose();
  };

  const handleClose = () => {
    setTableName('');
    setColumns([
      { name: 'Name', type: 'text' },
      { name: 'Amount', type: 'number' }
    ]);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Create New Table">
      <form onSubmit={handleSubmit} className="space-y-6">
        <Input
          label="Table Name"
          value={tableName}
          onChange={(e) => setTableName(e.target.value)}
          placeholder={`Enter ${currentTab} table name`}
          required
        />

        <div>
          <label className="block text-sm font-semibold text-white/90 mb-3">
            Columns
          </label>
          <div className="space-y-3">
            {columns.map((column, index) => (
              <div key={index} className="flex items-center space-x-3">
                <input
                  type="text"
                  value={column.name}
                  onChange={(e) => updateColumn(index, 'name', e.target.value)}
                  placeholder="Column name"
                  className="flex-1 px-4 py-3 glass-input rounded-xl text-white placeholder-white/60"
                  required
                />
                <select
                  value={column.type}
                  onChange={(e) => updateColumn(index, 'type', e.target.value as 'text' | 'number' | 'date')}
                  className="px-4 py-3 glass-input rounded-xl text-white bg-transparent"
                >
                  <option value="text" className="bg-gray-800">Text</option>
                  <option value="number" className="bg-gray-800">Number</option>
                  <option value="date" className="bg-gray-800">Date</option>
                </select>
                {columns.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeColumn(index)}
                    className="text-red-400 hover:text-red-300 p-2 hover:bg-red-400/20 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={addColumn}
            className="mt-4 flex items-center text-green-400 hover:text-green-300 font-medium transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Column
          </button>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button type="submit">
            Create Table
          </Button>
        </div>
      </form>
    </Modal>
  );
};