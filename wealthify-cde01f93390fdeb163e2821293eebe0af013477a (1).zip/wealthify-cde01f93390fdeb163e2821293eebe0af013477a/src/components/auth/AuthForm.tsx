import React, { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { Card } from '../ui/Card'
import { ThemeToggle } from '../ui/ThemeToggle'
import { DollarSign, Mail, Lock, User, Sparkles } from 'lucide-react'

export const AuthForm: React.FC = () => {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { signIn, signUp } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const { error } = isSignUp 
        ? await signUp(email, password)
        : await signIn(email, password)

      if (error) {
        setError(error.message)
      }
    } catch (err) {
      setError('An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      {/* Floating money symbols */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 text-6xl text-green-400/20 floating-animation">$</div>
        <div className="absolute top-40 right-20 text-4xl text-yellow-400/20 floating-animation" style={{animationDelay: '1s'}}>€</div>
        <div className="absolute bottom-40 left-20 text-5xl text-green-300/20 floating-animation" style={{animationDelay: '2s'}}>¥</div>
        <div className="absolute bottom-20 right-10 text-3xl text-yellow-300/20 floating-animation" style={{animationDelay: '3s'}}>£</div>
        <div className="absolute top-60 left-1/2 text-4xl text-green-500/20 floating-animation" style={{animationDelay: '0.5s'}}>₹</div>
      </div>

      <div className="max-w-md w-full relative z-10">
        <div className="flex justify-end mb-6">
          <ThemeToggle />
        </div>
        
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="money-gradient p-4 rounded-full shadow-2xl">
                <DollarSign className="w-10 h-10 text-white" />
              </div>
              <div className="absolute -top-1 -right-1">
                <Sparkles className="w-6 h-6 text-yellow-300 animate-pulse" />
              </div>
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-3 money-gradient-text">Financial Dashboard</h1>
          <p className="text-white/80 text-lg">Manage your wealth with elegance</p>
        </div>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-2 money-gradient-text">
                {isSignUp ? 'Create Account' : 'Welcome Back'}
              </h2>
              <p className="text-white/70">
                {isSignUp 
                  ? 'Start your financial journey today' 
                  : 'Sign in to your wealth dashboard'
                }
              </p>
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-400/50 rounded-xl p-4 backdrop-blur-sm">
                <p className="text-red-200 text-sm">{error}</p>
              </div>
            )}

            <div className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-12"
                  required
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
                <Input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-12"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              loading={loading}
              className="w-full text-lg py-4"
            >
              {isSignUp ? (
                <>
                  <User className="w-5 h-5 mr-2" />
                  Create Account
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Sign In
                </>
              )}
            </Button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-green-300 hover:text-green-200 text-sm font-medium transition-colors underline decoration-dotted"
              >
                {isSignUp 
                  ? 'Already have an account? Sign in' 
                  : "Don't have an account? Sign up"
                }
              </button>
            </div>
          </form>
        </Card>

        <div className="mt-8 text-center text-sm text-white/60">
          <p>🔒 Secure authentication powered by Supabase</p>
        </div>
      </div>
    </div>
  )
}