import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { IncomeSource, Expense } from '../types';
import { formatCurrency } from '../utils/formatters';

interface Currency {
  code: string;
  symbol: string;
  name: string;
}

interface FinancialChartProps {
  incomeData: IncomeSource[];
  expenseData: Expense[];
  currency: Currency;
}

export const FinancialChart: React.FC<FinancialChartProps> = ({ incomeData, expenseData, currency }) => {
  const totalIncome = incomeData.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = expenseData.reduce((sum, item) => sum + item.amount, 0);
  const netCashFlow = totalIncome - totalExpenses;

  const data = [
    { name: 'Income', amount: totalIncome },
    { name: 'Expenses', amount: totalExpenses },
    { name: 'Net Cash Flow', amount: netCashFlow },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-4 rounded-xl border border-white/20">
          <p className="text-white font-semibold">{label}</p>
          <p className="text-green-300 font-bold">
            {formatCurrency(payload[0].value, currency)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-96 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <defs>
            <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4CAF50" />
              <stop offset="50%" stopColor="#8BC34A" />
              <stop offset="100%" stopColor="#FFEB3B" />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis 
            dataKey="name" 
            tick={{ fill: 'white', fontSize: 12 }}
            axisLine={{ stroke: 'rgba(255,255,255,0.2)' }}
          />
          <YAxis 
            tickFormatter={(value) => formatCurrency(value, currency)}
            tick={{ fill: 'white', fontSize: 12 }}
            axisLine={{ stroke: 'rgba(255,255,255,0.2)' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ color: 'white' }}
          />
          <Bar 
            dataKey="amount" 
            fill="url(#barGradient)"
            radius={[8, 8, 0, 0]}
            stroke="rgba(255,255,255,0.2)"
            strokeWidth={1}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};