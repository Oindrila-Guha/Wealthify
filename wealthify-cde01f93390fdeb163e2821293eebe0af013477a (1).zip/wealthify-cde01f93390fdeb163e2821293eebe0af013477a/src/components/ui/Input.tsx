import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="mb-4">
        {label && (
          <label className="block text-sm font-semibold text-white/90 mb-2">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={`
            w-full px-4 py-3 glass-input rounded-xl shadow-sm
            focus:outline-none focus:ring-2 focus:ring-green-400/50
            text-white placeholder-white/60
            transition-all duration-300
            ${error ? 'border-red-400/50 focus:border-red-400' : ''}
            ${className}
          `}
          {...props}
        />
        {error && <p className="mt-2 text-sm text-red-300">{error}</p>}
      </div>
    );
  }
);