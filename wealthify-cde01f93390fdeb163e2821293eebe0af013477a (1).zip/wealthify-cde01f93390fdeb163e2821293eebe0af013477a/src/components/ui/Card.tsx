import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'income' | 'expense' | 'asset' | 'liability';
}

export const Card: React.FC<CardProps> = ({ title, children, className = '', variant = 'default' }) => {
  const getVariantClasses = () => {
    switch (variant) {
      case 'income':
        return 'income-gradient glow-green';
      case 'expense':
        return 'expense-gradient glow-yellow';
      case 'asset':
        return 'asset-gradient glow-green';
      case 'liability':
        return 'liability-gradient glow-yellow';
      default:
        return '';
    }
  };

  return (
    <div className={`
      glass-card dark:glass-card-dark rounded-2xl overflow-hidden 
      transition-all duration-500 hover:scale-105 floating-animation
      ${getVariantClasses()} ${className}
    `}>
      {title && (
        <div className="px-6 py-4 border-b border-white/10">
          <h3 className="text-lg font-semibold text-white money-gradient-text">{title}</h3>
        </div>
      )}
      <div className="px-6 py-6">{children}</div>
    </div>
  );
};