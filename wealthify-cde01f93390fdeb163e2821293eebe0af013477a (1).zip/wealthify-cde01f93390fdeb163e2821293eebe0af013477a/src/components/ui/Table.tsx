import React, { useState } from 'react';
import { PenLine, Check, X, Plus, Trash2 } from 'lucide-react';

interface Column<T> {
  header: string;
  accessor: keyof T;
  type?: 'text' | 'number' | 'select';
  options?: string[];
  render?: (value: any) => React.ReactNode;
  editable?: boolean;
}

interface TableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (item: T) => void;
  onRowUpdate?: (oldItem: T, newItem: T) => void;
  onRowDelete?: (item: T, index: number) => void;
  onAddRow?: () => void;
  showAddButton?: boolean;
  canDeleteRow?: (index: number) => boolean;
}

export function Table<T>({ 
  columns, 
  data, 
  onRowClick, 
  onRowUpdate, 
  onRowDelete, 
  onAddRow, 
  showAddButton = true,
  canDeleteRow
}: TableProps<T>) {
  const [editingCell, setEditingCell] = useState<{ rowIndex: number; column: keyof T } | null>(null);
  const [editValue, setEditValue] = useState<string>('');

  const handleEditClick = (rowIndex: number, column: keyof T, value: any) => {
    setEditingCell({ rowIndex, column });
    setEditValue(String(value));
  };

  const handleSave = (rowIndex: number, column: keyof T) => {
    if (!onRowUpdate) return;

    const oldItem = data[rowIndex];
    let newValue: any = editValue;
    
    const columnDef = columns.find(col => col.accessor === column);
    if (columnDef?.type === 'number') {
      newValue = parseFloat(editValue) || 0;
    } else if (column === 'frequency') {
      if (!editValue.match(/^\d+\s+months$|^yearly$/)) {
        alert('Please enter frequency as "X months" or "yearly"');
        return;
      }
    }

    const newItem = {
      ...oldItem,
      [column]: newValue,
    };

    onRowUpdate(oldItem, newItem);
    setEditingCell(null);
  };

  const handleCancel = () => {
    setEditingCell(null);
  };

  const handleDelete = (item: T, index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onRowDelete) {
      onRowDelete(item, index);
    }
  };

  const renderCell = (item: T, column: Column<T>, rowIndex: number) => {
    const value = item[column.accessor];
    const isEditing = editingCell?.rowIndex === rowIndex && editingCell?.column === column.accessor;

    if (isEditing) {
      return (
        <div className="flex items-center">
          <input
            type={column.type === 'number' ? 'number' : 'text'}
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            className="w-full px-3 py-2 glass-input rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400/50 text-white"
            autoFocus
            placeholder={column.accessor === 'frequency' ? 'e.g., "12 months" or "yearly"' : ''}
          />
          <button
            onClick={() => handleSave(rowIndex, column.accessor)}
            className="ml-2 text-green-400 hover:text-green-300 p-1 hover:bg-green-400/20 rounded"
          >
            <Check className="w-4 h-4" />
          </button>
          <button
            onClick={handleCancel}
            className="ml-2 text-red-400 hover:text-red-300 p-1 hover:bg-red-400/20 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      );
    }

    return (
      <div className="flex items-center justify-between">
        <span className="text-white/90 font-medium">
          {column.render ? column.render(value) : String(value)}
        </span>
        <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
          {column.editable && (
            <button
              onClick={() => handleEditClick(rowIndex, column.accessor, value)}
              className="ml-2 text-blue-400 hover:text-blue-300 p-1 hover:bg-blue-400/20 rounded"
            >
              <PenLine className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  };

  const shouldShowDeleteButton = (index: number) => {
    if (!onRowDelete) return false;
    if (canDeleteRow) return canDeleteRow(index);
    return true;
  };

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto">
        <div className="glass-card rounded-2xl overflow-hidden">
          <table className="min-w-full">
            <thead className="bg-gradient-to-r from-green-600/30 to-yellow-600/30">
              <tr>
                {columns.map((column, index) => (
                  <th
                    key={index}
                    className="px-6 py-4 text-left text-sm font-bold text-white/90 uppercase tracking-wider"
                  >
                    {column.header}
                  </th>
                ))}
                {onRowDelete && (
                  <th className="px-6 py-4 text-left text-sm font-bold text-white/90 uppercase tracking-wider">
                    Actions
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {data.map((item, rowIndex) => (
                <tr
                  key={rowIndex}
                  onClick={() => !editingCell && onRowClick?.(item)}
                  className={`group ${onRowClick && !editingCell ? 'cursor-pointer hover:bg-white/5' : ''} transition-all duration-300`}
                >
                  {columns.map((column, colIndex) => (
                    <td
                      key={colIndex}
                      className="px-6 py-4 whitespace-nowrap text-sm"
                    >
                      {renderCell(item, column, rowIndex)}
                    </td>
                  ))}
                  {onRowDelete && (
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {shouldShowDeleteButton(rowIndex) ? (
                        <button
                          onClick={(e) => handleDelete(item, rowIndex, e)}
                          className="text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition-all p-2 hover:bg-red-400/20 rounded-lg"
                          title="Delete row"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      ) : (
                        <span className="text-gray-500" title="Cannot delete default rows">
                          <Trash2 className="w-4 h-4 opacity-30" />
                        </span>
                      )}
                    </td>
                  )}
                </tr>
              ))}
              {data.length === 0 && (
                <tr>
                  <td colSpan={columns.length + (onRowDelete ? 1 : 0)} className="px-6 py-12 text-center text-white/60">
                    No data available. Click "Add Row" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {showAddButton && onAddRow && (
        <button
          onClick={onAddRow}
          className="flex items-center px-6 py-3 glass-button text-white hover:bg-white/20 rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Row
        </button>
      )}
    </div>
  );
}