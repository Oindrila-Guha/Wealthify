import React from 'react';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'glass';
  loading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ children, variant = 'primary', loading, className = '', ...props }, ref) => {
    const baseStyles = 'px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105';
    const variants = {
      primary: 'money-gradient text-white shadow-lg hover:shadow-xl',
      secondary: 'bg-gradient-to-r from-gray-600 to-gray-700 text-white hover:from-gray-700 hover:to-gray-800 shadow-lg',
      outline: 'glass-button text-white hover:text-gray-900',
      glass: 'glass-button text-white backdrop-blur-md'
    };

    return (
      <button
        ref={ref}
        className={`
          ${baseStyles}
          ${variants[variant]}
          ${loading ? 'opacity-70 cursor-not-allowed' : ''}
          ${className}
        `}
        disabled={loading || props.disabled}
        {...props}
      >
        {loading ? (
          <span className="flex items-center">
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Loading...
          </span>
        ) : (
          children
        )}
      </button>
    );
  }
);