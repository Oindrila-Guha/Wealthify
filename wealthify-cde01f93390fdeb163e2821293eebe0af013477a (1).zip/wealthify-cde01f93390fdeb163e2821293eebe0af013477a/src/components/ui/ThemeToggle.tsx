import React from 'react'
import { Sun, Moon } from 'lucide-react'
import { useTheme } from '../../contexts/ThemeContext'

export const ThemeToggle: React.FC = () => {
  const { isDark, toggleTheme } = useTheme()

  return (
    <button
      onClick={toggleTheme}
      className="
        relative inline-flex items-center justify-center
        w-12 h-12 rounded-full glass-button
        hover:scale-110 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-green-400/50
        group floating-animation
      "
      title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
    >
      <div className="relative w-6 h-6">
        <Sun 
          className={`
            absolute inset-0 w-6 h-6 text-yellow-300
            transition-all duration-500 ease-in-out
            ${isDark ? 'opacity-0 rotate-90 scale-0' : 'opacity-100 rotate-0 scale-100'}
          `}
        />
        <Moon 
          className={`
            absolute inset-0 w-6 h-6 text-blue-300
            transition-all duration-500 ease-in-out
            ${isDark ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-0'}
          `}
        />
      </div>
      
      <div className={`
        absolute inset-0 rounded-full opacity-0 group-hover:opacity-30
        transition-opacity duration-300
        ${isDark ? 'bg-blue-400' : 'bg-yellow-400'}
      `} />
    </button>
  )
}