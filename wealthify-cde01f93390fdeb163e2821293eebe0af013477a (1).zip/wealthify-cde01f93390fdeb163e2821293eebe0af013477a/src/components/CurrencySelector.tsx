import React, { useState } from 'react'
import { Globe, Check } from 'lucide-react'
import { Button } from './ui/Button'

interface Currency {
  code: string
  symbol: string
  name: string
}

const currencies: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'BRL', symbol: 'R$', name: 'Brazilian Real' },
]

interface CurrencySelectorProps {
  selectedCurrency: Currency
  onCurrencyChange: (currency: Currency) => void
}

export const CurrencySelector: React.FC<CurrencySelectorProps> = ({
  selectedCurrency,
  onCurrencyChange,
}) => {
  const [isOpen, setIsOpen] = useState(false)

  const handleCurrencySelect = (currency: Currency) => {
    onCurrencyChange(currency)
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <Button
        variant="glass"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2"
      >
        <Globe className="w-4 h-4" />
        <span>{selectedCurrency.symbol} {selectedCurrency.code}</span>
      </Button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-64 glass-card rounded-2xl shadow-2xl z-20 max-h-80 overflow-y-auto">
            <div className="p-2">
              <div className="text-sm font-semibold text-white/90 px-4 py-3 border-b border-white/10">
                Select Currency
              </div>
              {currencies.map((currency) => (
                <button
                  key={currency.code}
                  onClick={() => handleCurrencySelect(currency)}
                  className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-white/10 rounded-xl transition-all duration-200 m-1"
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono text-lg text-yellow-300">{currency.symbol}</span>
                    <div>
                      <div className="font-semibold text-white">{currency.code}</div>
                      <div className="text-sm text-white/70">{currency.name}</div>
                    </div>
                  </div>
                  {selectedCurrency.code === currency.code && (
                    <Check className="w-4 h-4 text-green-400" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}