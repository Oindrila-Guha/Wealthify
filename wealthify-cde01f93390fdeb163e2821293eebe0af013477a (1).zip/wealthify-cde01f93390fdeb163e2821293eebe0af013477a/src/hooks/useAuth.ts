import { useState, useEffect } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // For demo purposes, simulate a logged-in user if Supabase is not configured
    const isDemoMode = import.meta.env.VITE_SUPABASE_URL === 'https://demo.supabase.co' || 
                       !import.meta.env.VITE_SUPABASE_URL

    if (isDemoMode) {
      // Simulate a demo user
      const demoUser = {
        id: 'demo-user-id',
        email: 'demo@example.com',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        aud: 'authenticated',
        role: 'authenticated'
      } as User
      
      setUser(demoUser)
      setLoading(false)
      return
    }

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const signUp = async (email: string, password: string) => {
    const isDemoMode = import.meta.env.VITE_SUPABASE_URL === 'https://demo.supabase.co' || 
                       !import.meta.env.VITE_SUPABASE_URL

    if (isDemoMode) {
      // Demo mode - simulate successful signup
      const demoUser = {
        id: 'demo-user-id',
        email: email,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        aud: 'authenticated',
        role: 'authenticated'
      } as User
      
      setUser(demoUser)
      return { data: { user: demoUser, session: null }, error: null }
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })
    return { data, error }
  }

  const signIn = async (email: string, password: string) => {
    const isDemoMode = import.meta.env.VITE_SUPABASE_URL === 'https://demo.supabase.co' || 
                       !import.meta.env.VITE_SUPABASE_URL

    if (isDemoMode) {
      // Demo mode - simulate successful signin
      const demoUser = {
        id: 'demo-user-id',
        email: email,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        aud: 'authenticated',
        role: 'authenticated'
      } as User
      
      setUser(demoUser)
      return { data: { user: demoUser, session: null }, error: null }
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    return { data, error }
  }

  const signOut = async () => {
    const isDemoMode = import.meta.env.VITE_SUPABASE_URL === 'https://demo.supabase.co' || 
                       !import.meta.env.VITE_SUPABASE_URL

    if (isDemoMode) {
      // Demo mode - simulate signout
      setUser(null)
      return { error: null }
    }

    const { error } = await supabase.auth.signOut()
    return { error }
  }

  return {
    user,
    loading,
    signUp,
    signIn,
    signOut,
  }
}