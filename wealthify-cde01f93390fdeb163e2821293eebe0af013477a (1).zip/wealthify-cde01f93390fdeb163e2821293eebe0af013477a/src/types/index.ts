export interface IncomeSource {
  id: string;
  name: string;
  amount: number;
  type: 'salary' | 'investment' | 'business' | 'other';
  frequency: string;
}

export interface Expense {
  id: string;
  name: string;
  amount: number;
  category: 'tax' | 'mortgage' | 'loan' | 'credit' | 'retail' | 'other';
  dueDate?: Date;
}

export interface Asset {
  id: string;
  name: string;
  value: number;
  type: 'stock' | 'fund' | 'realestate' | 'business' | 'other';
  purchaseDate?: Date;
}

export interface Liability {
  id: string;
  name: string;
  amount: number;
  type: 'mortgage' | 'loan' | 'credit' | 'other';
  interestRate?: number;
}

export interface CustomTable {
  id: string;
  name: string;
  type: 'income' | 'expenses' | 'assets' | 'liabilities';
  columns: Array<{
    name: string;
    type: 'text' | 'number' | 'date';
  }>;
  rows: Array<Record<string, any>>;
}