interface Currency {
  code: string
  symbol: string
  name: string
}

export const formatCurrency = (amount: number, currency: Currency = { code: 'USD', symbol: '$', name: 'US Dollar' }): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.code,
  }).format(amount);
};

export const formatCurrencyWithMillions = (amount: number, currency: Currency = { code: 'USD', symbol: '$', name: 'US Dollar' }): string => {
  const absAmount = Math.abs(amount);
  
  if (absAmount >= 1000000) {
    const millionValue = amount / 1000000;
    const formattedValue = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.code,
      minimumFractionDigits: millionValue % 1 === 0 ? 0 : 1,
      maximumFractionDigits: 2,
    }).format(millionValue);
    
    return `${formattedValue}M`;
  }
  
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.code,
  }).format(amount);
};

// Helper function to determine text size based on number length
export const getResponsiveTextSize = (amount: number): string => {
  const absAmount = Math.abs(amount);
  const numString = Math.floor(absAmount).toString();
  
  if (numString.length >= 8) {
    return 'text-lg'; // 8+ digits (10M+)
  } else if (numString.length >= 7) {
    return 'text-xl'; // 7 digits (1M-9.9M)
  } else if (numString.length >= 6) {
    return 'text-xl'; // 6 digits (100K-999K)
  } else {
    return 'text-2xl'; // 5 digits or less
  }
};

export const calculateTotal = (items: { amount: number }[]): number => {
  return items.reduce((sum, item) => sum + item.amount, 0);
};