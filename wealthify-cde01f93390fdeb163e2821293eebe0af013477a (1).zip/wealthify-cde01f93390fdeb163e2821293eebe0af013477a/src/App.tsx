import React, { useState } from 'react';
import { PlusCircle, DollarSign, CreditCard, Wallet, Plus, BarChart, LogOut, Settings, TrendingUp, Coins } from 'lucide-react';
import { Card } from './components/ui/Card';
import { Button } from './components/ui/Button';
import { Table } from './components/ui/Table';
import { FinancialChart } from './components/FinancialChart';
import { NewTableModal } from './components/NewTableModal';
import { ConfirmDialog } from './components/ui/ConfirmDialog';
import { AuthForm } from './components/auth/AuthForm';
import { CurrencySelector } from './components/CurrencySelector';
import { ThemeToggle } from './components/ui/ThemeToggle';
import { useAuth } from './hooks/useAuth';
import { formatCurrency, formatCurrencyWithMillions, getResponsiveTextSize } from './utils/formatters';
import type { IncomeSource, Expense, Asset, Liability, CustomTable } from './types';

interface Currency {
  code: string;
  symbol: string;
  name: string;
}

function App() {
  const { user, loading, signOut } = useAuth();
  const [activeTab, setActiveTab] = React.useState<'income' | 'expenses' | 'assets' | 'liabilities'>('income');
  const [customTables, setCustomTables] = React.useState<CustomTable[]>([]);
  const [showNewTableModal, setShowNewTableModal] = React.useState(false);
  const [showChart, setShowChart] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>({
    code: 'USD',
    symbol: '$',
    name: 'US Dollar'
  });
  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    type: 'table' | 'row';
    tableId?: string;
    tableName?: string;
    rowIndex?: number;
    onConfirm?: () => void;
  }>({ isOpen: false, type: 'table' });
  
  const [incomeData, setIncomeData] = useState<IncomeSource[]>([
    { id: '1', name: 'Salary', amount: 5000, type: 'salary', frequency: '12 months' },
    { id: '2', name: 'Investments', amount: 1000, type: 'investment', frequency: 'yearly' },
  ]);

  const [expenseData, setExpenseData] = useState<Expense[]>([
    { id: '1', name: 'Rent', amount: 1500, category: 'mortgage' },
    { id: '2', name: 'Car Payment', amount: 400, category: 'loan' },
  ]);

  const [assetData, setAssetData] = useState<Asset[]>([]);
  const [liabilityData, setLiabilityData] = useState<Liability[]>([]);

  // Show loading spinner while checking auth
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-green-400/30 border-t-green-400 mx-auto mb-4"></div>
            <Coins className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-green-400" />
          </div>
          <p className="text-white/80 text-lg">Loading your Wealthify dashboard...</p>
        </div>
      </div>
    );
  }

  // Show auth form if not authenticated
  if (!user) {
    return <AuthForm />;
  }

  const totalIncome = incomeData.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = expenseData.reduce((sum, item) => sum + item.amount, 0);
  const totalAssets = assetData.reduce((sum, item) => sum + item.value, 0);
  const totalLiabilities = liabilityData.reduce((sum, item) => sum + item.amount, 0);
  const netCashFlow = totalIncome - totalExpenses;
  const netWorth = totalAssets - totalLiabilities;

  const formatCurrencyWithSelected = (amount: number) => formatCurrency(amount, selectedCurrency);
  const formatCurrencyWithSelectedMillions = (amount: number) => formatCurrencyWithMillions(amount, selectedCurrency);

  const incomeColumns = [
    { header: 'Name', accessor: 'name' as const, editable: true },
    { header: 'Amount', accessor: 'amount' as const, render: formatCurrencyWithSelected, editable: true, type: 'number' as const },
    { header: 'Type', accessor: 'type' as const, editable: true },
    { header: 'Frequency', accessor: 'frequency' as const, editable: true },
  ];

  const expenseColumns = [
    { header: 'Name', accessor: 'name' as const, editable: true },
    { header: 'Amount', accessor: 'amount' as const, render: formatCurrencyWithSelected, editable: true, type: 'number' as const },
    { header: 'Category', accessor: 'category' as const, editable: true },
  ];

  const assetColumns = [
    { header: 'Name', accessor: 'name' as const, editable: true },
    { header: 'Value', accessor: 'value' as const, render: formatCurrencyWithSelected, editable: true, type: 'number' as const },
    { header: 'Type', accessor: 'type' as const, editable: true },
  ];

  const liabilityColumns = [
    { header: 'Name', accessor: 'name' as const, editable: true },
    { header: 'Amount', accessor: 'amount' as const, render: formatCurrencyWithSelected, editable: true, type: 'number' as const },
    { header: 'Type', accessor: 'type' as const, editable: true },
    { header: 'Interest Rate', accessor: 'interestRate' as const, editable: true, type: 'number' as const },
  ];

  const handleSignOut = async () => {
    await signOut();
  };

  const handleIncomeUpdate = (oldItem: IncomeSource, newItem: IncomeSource) => {
    setIncomeData(incomeData.map(item => item.id === oldItem.id ? newItem : item));
  };

  const handleExpenseUpdate = (oldItem: Expense, newItem: Expense) => {
    setExpenseData(expenseData.map(item => item.id === oldItem.id ? newItem : item));
  };

  const handleAssetUpdate = (oldItem: Asset, newItem: Asset) => {
    setAssetData(assetData.map(item => item.id === oldItem.id ? newItem : item));
  };

  const handleLiabilityUpdate = (oldItem: Liability, newItem: Liability) => {
    setLiabilityData(liabilityData.map(item => item.id === oldItem.id ? newItem : item));
  };

  const handleIncomeDelete = (item: IncomeSource, index: number) => {
    if (index < 2) {
      alert('Cannot delete default income sources. You can only delete rows you have added.');
      return;
    }
    setIncomeData(incomeData.filter(income => income.id !== item.id));
  };

  const handleExpenseDelete = (item: Expense, index: number) => {
    if (index < 2) {
      alert('Cannot delete default expenses. You can only delete rows you have added.');
      return;
    }
    setExpenseData(expenseData.filter(expense => expense.id !== item.id));
  };

  const handleAssetDelete = (item: Asset) => {
    setAssetData(assetData.filter(asset => asset.id !== item.id));
  };

  const handleLiabilityDelete = (item: Liability) => {
    setLiabilityData(liabilityData.filter(liability => liability.id !== item.id));
  };

  const handleAddIncome = () => {
    const newIncome: IncomeSource = {
      id: Date.now().toString(),
      name: 'New Income',
      amount: 0,
      type: 'other',
      frequency: '12 months'
    };
    setIncomeData([...incomeData, newIncome]);
  };

  const handleAddExpense = () => {
    const newExpense: Expense = {
      id: Date.now().toString(),
      name: 'New Expense',
      amount: 0,
      category: 'other'
    };
    setExpenseData([...expenseData, newExpense]);
  };

  const handleAddAsset = () => {
    const newAsset: Asset = {
      id: Date.now().toString(),
      name: 'New Asset',
      value: 0,
      type: 'other'
    };
    setAssetData([...assetData, newAsset]);
  };

  const handleAddLiability = () => {
    const newLiability: Liability = {
      id: Date.now().toString(),
      name: 'New Liability',
      amount: 0,
      type: 'other',
      interestRate: 0
    };
    setLiabilityData([...liabilityData, newLiability]);
  };

  const handleCreateTable = (tableData: Omit<CustomTable, 'id'>) => {
    const newTable: CustomTable = {
      ...tableData,
      id: Date.now().toString(),
    };
    setCustomTables([...customTables, newTable]);
  };

  const handleDeleteTable = (tableId: string) => {
    const table = customTables.find(t => t.id === tableId);
    if (!table) return;

    setDeleteConfirm({
      isOpen: true,
      type: 'table',
      tableId,
      tableName: table.name,
      onConfirm: () => {
        setCustomTables(customTables.filter(t => t.id !== tableId));
        setDeleteConfirm({ isOpen: false, type: 'table' });
      }
    });
  };

  const handleAddRowToCustomTable = (tableId: string) => {
    const table = customTables.find(t => t.id === tableId);
    if (!table) return;

    const newRow: Record<string, any> = {};
    table.columns.forEach(col => {
      newRow[col.name.toLowerCase()] = col.type === 'number' ? 0 : '';
    });

    const updatedTables = customTables.map(t => 
      t.id === tableId 
        ? { ...t, rows: [...t.rows, newRow] }
        : t
    );
    setCustomTables(updatedTables);
  };

  const handleDeleteRowFromCustomTable = (tableId: string, rowIndex: number) => {
    const table = customTables.find(t => t.id === tableId);
    if (!table) return;

    setDeleteConfirm({
      isOpen: true,
      type: 'row',
      tableId,
      tableName: table.name,
      rowIndex,
      onConfirm: () => {
        const updatedTables = customTables.map(t => 
          t.id === tableId 
            ? { ...t, rows: t.rows.filter((_, index) => index !== rowIndex) }
            : t
        );
        setCustomTables(updatedTables);
        setDeleteConfirm({ isOpen: false, type: 'table' });
      }
    });
  };

  const handleCustomTableUpdate = (tableId: string, oldRow: any, newRow: any) => {
    const updatedTables = customTables.map(table => {
      if (table.id === tableId) {
        const updatedRows = table.rows.map(row => 
          row === oldRow ? newRow : row
        );
        return { ...table, rows: updatedRows };
      }
      return table;
    });
    setCustomTables(updatedTables);
  };

  const getCustomTablesForType = (type: 'income' | 'expenses' | 'assets' | 'liabilities') => {
    return customTables.filter(table => table.type === type);
  };

  const getTableTotal = (table: CustomTable): number => {
    const amountColumn = table.columns.find(col => 
      col.name.toLowerCase().includes('amount') || 
      col.name.toLowerCase().includes('value')
    );
    
    if (!amountColumn) return 0;
    
    return table.rows.reduce((sum, row) => {
      const value = row[amountColumn.name.toLowerCase()];
      return sum + (typeof value === 'number' ? value : 0);
    }, 0);
  };

  const canDeleteRow = (index: number, tableType: 'income' | 'expenses' | 'assets' | 'liabilities') => {
    if (tableType === 'income' || tableType === 'expenses') {
      return index >= 2;
    }
    return true;
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Floating background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-8xl text-green-400/10 floating-animation">$</div>
        <div className="absolute top-20 right-20 text-6xl text-yellow-400/10 floating-animation" style={{animationDelay: '1s'}}>€</div>
        <div className="absolute bottom-20 left-20 text-7xl text-green-300/10 floating-animation" style={{animationDelay: '2s'}}>¥</div>
        <div className="absolute bottom-10 right-10 text-5xl text-yellow-300/10 floating-animation" style={{animationDelay: '3s'}}>£</div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2 money-gradient-text">Wealthify</h1>
            <p className="text-white/80 text-lg">Welcome back, <span className="text-green-300 font-semibold">{user.email}</span></p>
          </div>
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <CurrencySelector
              selectedCurrency={selectedCurrency}
              onCurrencyChange={setSelectedCurrency}
            />
            <Button variant="glass" onClick={() => setShowChart(!showChart)}>
              <BarChart className="w-4 h-4 mr-2" />
              {showChart ? 'Hide Chart' : 'Show Chart'}
            </Button>
            <Button variant="glass" onClick={() => setShowNewTableModal(true)}>
              <PlusCircle className="w-4 h-4 mr-2" />
              Add Table
            </Button>
            <Button variant="outline" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        {showChart && (
          <div className="mb-8">
            <Card>
              <FinancialChart 
                incomeData={incomeData} 
                expenseData={expenseData}
                currency={selectedCurrency}
              />
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card variant="income" className="transform hover:scale-105 transition-all duration-300">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-400/20 mr-4">
                <TrendingUp className="w-8 h-8 text-green-300" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white/70 font-medium">Total Income</p>
                <p className={`${getResponsiveTextSize(totalIncome)} font-bold text-white break-words`}>
                  {formatCurrencyWithSelectedMillions(totalIncome)}
                </p>
              </div>
            </div>
          </Card>

          <Card variant="expense" className="transform hover:scale-105 transition-all duration-300">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-400/20 mr-4">
                <CreditCard className="w-8 h-8 text-yellow-300" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white/70 font-medium">Total Expenses</p>
                <p className={`${getResponsiveTextSize(totalExpenses)} font-bold text-white break-words`}>
                  {formatCurrencyWithSelectedMillions(totalExpenses)}
                </p>
              </div>
            </div>
          </Card>

          <Card className={`transform hover:scale-105 transition-all duration-300 ${netCashFlow >= 0 ? "glow-green" : "glow-yellow"}`}>
            <div className="flex items-center">
              <div className={`p-3 rounded-full ${netCashFlow >= 0 ? "bg-green-400/20" : "bg-yellow-400/20"} mr-4`}>
                <Wallet className={`w-8 h-8 ${netCashFlow >= 0 ? "text-green-300" : "text-yellow-300"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white/70 font-medium">Net Cash Flow</p>
                <p className={`${getResponsiveTextSize(netCashFlow)} font-bold ${netCashFlow >= 0 ? "text-green-300" : "text-yellow-300"} break-words`}>
                  {formatCurrencyWithSelectedMillions(netCashFlow)}
                </p>
              </div>
            </div>
          </Card>

          <Card className={`transform hover:scale-105 transition-all duration-300 ${netWorth >= 0 ? "glow-green" : "glow-yellow"}`}>
            <div className="flex items-center">
              <div className={`p-3 rounded-full ${netWorth >= 0 ? "bg-green-400/20" : "bg-yellow-400/20"} mr-4`}>
                <Coins className={`w-8 h-8 ${netWorth >= 0 ? "text-green-300" : "text-yellow-300"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white/70 font-medium">Net Worth</p>
                <p className={`${getResponsiveTextSize(netWorth)} font-bold ${netWorth >= 0 ? "text-green-300" : "text-yellow-300"} break-words`}>
                  {formatCurrencyWithSelectedMillions(netWorth)}
                </p>
              </div>
            </div>
          </Card>
        </div>

        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="border-b border-white/10">
            <nav className="flex -mb-px">
              {(['income', 'expenses', 'assets', 'liabilities'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`
                    py-4 px-6 text-sm font-semibold capitalize transition-all duration-300 relative
                    ${activeTab === tab
                      ? 'text-white border-b-2 border-green-400'
                      : 'text-white/70 hover:text-white hover:bg-white/5'
                    }
                  `}
                >
                  {tab}
                  {activeTab === tab && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-green-400 to-yellow-400"></div>
                  )}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'income' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white money-gradient-text">Income Sources</h2>
                  <div className="text-xl font-bold text-green-300">
                    Total: {formatCurrencyWithSelectedMillions(totalIncome)}
                  </div>
                </div>
                <Table
                  columns={incomeColumns}
                  data={incomeData}
                  onRowClick={(item) => console.log('Clicked:', item)}
                  onRowUpdate={handleIncomeUpdate}
                  onRowDelete={handleIncomeDelete}
                  onAddRow={handleAddIncome}
                  canDeleteRow={(index) => canDeleteRow(index, 'income')}
                />
                {getCustomTablesForType('income').map(table => (
                  <div key={table.id} className="mt-8">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-bold text-white money-gradient-text">{table.name}</h2>
                      <div className="flex items-center gap-4">
                        <div className="text-xl font-bold text-green-300">
                          Total: {formatCurrencyWithSelectedMillions(getTableTotal(table))}
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleDeleteTable(table.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/20"
                        >
                          Delete Table
                        </Button>
                      </div>
                    </div>
                    <Table
                      columns={table.columns.map(col => ({
                        header: col.name,
                        accessor: col.name.toLowerCase() as any,
                        editable: true,
                        type: col.type === 'number' ? 'number' as const : 'text' as const,
                        render: col.type === 'number' ? formatCurrencyWithSelected : undefined
                      }))}
                      data={table.rows}
                      onRowClick={(item) => console.log('Clicked:', item)}
                      onRowUpdate={(oldRow, newRow) => handleCustomTableUpdate(table.id, oldRow, newRow)}
                      onRowDelete={(_, rowIndex) => handleDeleteRowFromCustomTable(table.id, rowIndex)}
                      onAddRow={() => handleAddRowToCustomTable(table.id)}
                    />
                  </div>
                ))}
              </div>
            )}
            {activeTab === 'expenses' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white money-gradient-text">Expenses</h2>
                  <div className="text-xl font-bold text-yellow-300">
                    Total: {formatCurrencyWithSelectedMillions(totalExpenses)}
                  </div>
                </div>
                <Table
                  columns={expenseColumns}
                  data={expenseData}
                  onRowClick={(item) => console.log('Clicked:', item)}
                  onRowUpdate={handleExpenseUpdate}
                  onRowDelete={handleExpenseDelete}
                  onAddRow={handleAddExpense}
                  canDeleteRow={(index) => canDeleteRow(index, 'expenses')}
                />
                {getCustomTablesForType('expenses').map(table => (
                  <div key={table.id} className="mt-8">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-bold text-white money-gradient-text">{table.name}</h2>
                      <div className="flex items-center gap-4">
                        <div className="text-xl font-bold text-yellow-300">
                          Total: {formatCurrencyWithSelectedMillions(getTableTotal(table))}
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleDeleteTable(table.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/20"
                        >
                          Delete Table
                        </Button>
                      </div>
                    </div>
                    <Table
                      columns={table.columns.map(col => ({
                        header: col.name,
                        accessor: col.name.toLowerCase() as any,
                        editable: true,
                        type: col.type === 'number' ? 'number' as const : 'text' as const,
                        render: col.type === 'number' ? formatCurrencyWithSelected : undefined
                      }))}
                      data={table.rows}
                      onRowClick={(item) => console.log('Clicked:', item)}
                      onRowUpdate={(oldRow, newRow) => handleCustomTableUpdate(table.id, oldRow, newRow)}
                      onRowDelete={(_, rowIndex) => handleDeleteRowFromCustomTable(table.id, rowIndex)}
                      onAddRow={() => handleAddRowToCustomTable(table.id)}
                    />
                  </div>
                ))}
              </div>
            )}
            {activeTab === 'assets' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white money-gradient-text">Assets</h2>
                  <div className="text-xl font-bold text-green-300">
                    Total: {formatCurrencyWithSelectedMillions(totalAssets)}
                  </div>
                </div>
                <Table
                  columns={assetColumns}
                  data={assetData}
                  onRowClick={(item) => console.log('Clicked:', item)}
                  onRowUpdate={handleAssetUpdate}
                  onRowDelete={handleAssetDelete}
                  onAddRow={handleAddAsset}
                />
                {getCustomTablesForType('assets').map(table => (
                  <div key={table.id} className="mt-8">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-bold text-white money-gradient-text">{table.name}</h2>
                      <div className="flex items-center gap-4">
                        <div className="text-xl font-bold text-green-300">
                          Total: {formatCurrencyWithSelectedMillions(getTableTotal(table))}
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleDeleteTable(table.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/20"
                        >
                          Delete Table
                        </Button>
                      </div>
                    </div>
                    <Table
                      columns={table.columns.map(col => ({
                        header: col.name,
                        accessor: col.name.toLowerCase() as any,
                        editable: true,
                        type: col.type === 'number' ? 'number' as const : 'text' as const,
                        render: col.type === 'number' ? formatCurrencyWithSelected : undefined
                      }))}
                      data={table.rows}
                      onRowClick={(item) => console.log('Clicked:', item)}
                      onRowUpdate={(oldRow, newRow) => handleCustomTableUpdate(table.id, oldRow, newRow)}
                      onRowDelete={(_, rowIndex) => handleDeleteRowFromCustomTable(table.id, rowIndex)}
                      onAddRow={() => handleAddRowToCustomTable(table.id)}
                    />
                  </div>
                ))}
              </div>
            )}
            {activeTab === 'liabilities' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white money-gradient-text">Liabilities</h2>
                  <div className="text-xl font-bold text-yellow-300">
                    Total: {formatCurrencyWithSelectedMillions(totalLiabilities)}
                  </div>
                </div>
                <Table
                  columns={liabilityColumns}
                  data={liabilityData}
                  onRowClick={(item) => console.log('Clicked:', item)}
                  onRowUpdate={handleLiabilityUpdate}
                  onRowDelete={handleLiabilityDelete}
                  onAddRow={handleAddLiability}
                />
                {getCustomTablesForType('liabilities').map(table => (
                  <div key={table.id} className="mt-8">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-bold text-white money-gradient-text">{table.name}</h2>
                      <div className="flex items-center gap-4">
                        <div className="text-xl font-bold text-yellow-300">
                          Total: {formatCurrencyWithSelectedMillions(getTableTotal(table))}
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleDeleteTable(table.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/20"
                        >
                          Delete Table
                        </Button>
                      </div>
                    </div>
                    <Table
                      columns={table.columns.map(col => ({
                        header: col.name,
                        accessor: col.name.toLowerCase() as any,
                        editable: true,
                        type: col.type === 'number' ? 'number' as const : 'text' as const,
                        render: col.type === 'number' ? formatCurrencyWithSelected : undefined
                      }))}
                      data={table.rows}
                      onRowClick={(item) => console.log('Clicked:', item)}
                      onRowUpdate={(oldRow, newRow) => handleCustomTableUpdate(table.id, oldRow, newRow)}
                      onRowDelete={(_, rowIndex) => handleDeleteRowFromCustomTable(table.id, rowIndex)}
                      onAddRow={() => handleAddRowToCustomTable(table.id)}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <NewTableModal
        isOpen={showNewTableModal}
        onClose={() => setShowNewTableModal(false)}
        onCreateTable={handleCreateTable}
        currentTab={activeTab}
      />

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        onClose={() => setDeleteConfirm({ isOpen: false, type: 'table' })}
        onConfirm={deleteConfirm.onConfirm || (() => {})}
        title={deleteConfirm.type === 'table' ? 'Delete Table' : 'Delete Row'}
        message={
          deleteConfirm.type === 'table'
            ? `Are you sure you want to delete the table "${deleteConfirm.tableName}"? This action cannot be undone and will permanently remove all data in this table.`
            : `Are you sure you want to delete this row from "${deleteConfirm.tableName}"? This action cannot be undone.`
        }
        confirmText="Delete"
        confirmVariant="danger"
      />
    </div>
  );
}

export default App;